package my_package;

public class Class {

}
